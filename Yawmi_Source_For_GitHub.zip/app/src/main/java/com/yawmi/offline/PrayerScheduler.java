package com.yawmi.offline;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import java.time.LocalDate;
import java.time.ZonedDateTime;

public final class PrayerScheduler {
    public static final String ACTION_PRAYER="com.yawmi.offline.PRAYER";
    public static final String ACTION_REFRESH="com.yawmi.offline.REFRESH";
    private static final int REFRESH_ID=900111;

    public static boolean exactAllowed(Context ctx) {
        AlarmManager manager=(AlarmManager)ctx.getSystemService(Context.ALARM_SERVICE);
        return Build.VERSION.SDK_INT<31||manager.canScheduleExactAlarms();
    }
    public static void schedule(Context ctx) {
        AlarmManager alarms=(AlarmManager)ctx.getSystemService(Context.ALARM_SERVICE);
        SharedPreferences prefs=ctx.getSharedPreferences("yawmi_prefs",Context.MODE_PRIVATE);
        int cityIndex=Math.min(PrayerTimes.CITIES.length-1,Math.max(0,prefs.getInt("city",0)));
        PrayerTimes.City city=PrayerTimes.CITIES[cityIndex];
        int lead=Math.min(60,Math.max(0,prefs.getInt("remind",15)));
        LocalDate today=LocalDate.now(java.time.ZoneId.of(city.zone));
        long now=System.currentTimeMillis();
        for(int offset=-1;offset<=9;offset++) {
            LocalDate date=today.plusDays(offset);
            ZonedDateTime[] at=PrayerTimes.calculate(date,city,prefs);
            for(int i=0;i<5;i++) {
                int id=(int)(date.toEpochDay()*10L+i);
                Intent intent=new Intent(ctx,PrayerAlarmReceiver.class).setAction(ACTION_PRAYER)
                    .putExtra("prayer",PrayerTimes.NAMES_AR[i]).putExtra("lead",lead)
                    .putExtra("id",id).putExtra("city",city.name);
                PendingIntent pi=PendingIntent.getBroadcast(ctx,id,intent,
                    PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                alarms.cancel(pi);
                if(offset>=0&&offset<=8) {
                    long millis=at[i].minusMinutes(lead).toInstant().toEpochMilli();
                    if(millis>now+1000) {
                        try {
                            if(exactAllowed(ctx))alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi);
                            else alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi);
                        }catch(SecurityException ex) {
                            alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi);
                        }
                    }
                }
            }
        }
        // Refresh the upcoming alarms tomorrow. This keeps notifications working beyond the first week.
        ZonedDateTime refresh=java.time.ZonedDateTime.now().toLocalDate().plusDays(1)
            .atTime(0,10).atZone(java.time.ZoneId.systemDefault());
        PendingIntent refreshPi=PendingIntent.getBroadcast(ctx,REFRESH_ID,
            new Intent(ctx,PrayerAlarmReceiver.class).setAction(ACTION_REFRESH),
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        alarms.cancel(refreshPi);
        alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,refresh.toInstant().toEpochMilli(),refreshPi);
    }
    private PrayerScheduler(){ }
}
