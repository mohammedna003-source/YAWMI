package com.yawmi.offline;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Offline keyword-based extraction, not a cloud AI model. Every proposed entry is confirmed before saving. */
public final class MoneyParser {
    private static final Pattern AMOUNT=Pattern.compile("(?<!\\d)(\\d+(?:\\.\\d+)?)(?:\\s*)(آلاف|الف|ألف|ملايين|مليون)?");
    public static List<Store.Transaction> parse(String text,String kind,String fallbackCurrency) {
        String normalized=normalizeDigits(text).replaceAll("(?<=\\d),(?=\\d{3}(?:\\D|$))", "");
        String[] parts=normalized.split("[،;\\n]|,(?!\\d{3}\\b)|\\s+و\\s*(?=\\d)");
        List<Store.Transaction> result=new ArrayList<>();
        String today=LocalDate.now().toString();
        for(String p:parts) {
            String part=p.trim();if(part.isEmpty())continue;
            Matcher m=AMOUNT.matcher(part);
            if(!m.find())continue;
            double amount;
            try{amount=Double.parseDouble(m.group(1));}catch(NumberFormatException ex){continue;}
            String unit=m.group(2);
            if(unit!=null) {
                if(unit.equals("مليون")||unit.equals("ملايين"))amount*=1000000;
                else amount*=1000;
            }
            if(!Double.isFinite(amount)||amount<=0)continue;
            String lower=part.toLowerCase(Locale.ROOT);
            String currency=lower.contains("دولار")||lower.contains("usd")||part.contains("$")?"USD":
                lower.contains("يورو")||lower.contains("eur")||part.contains("€")?"EUR":
                lower.contains("ليرة")||lower.contains("ل.س")||lower.contains("syp")?"SYP":fallbackCurrency;
            String title=(part.substring(0,m.start())+" "+part.substring(m.end())).replaceAll(
                "(?i)(دولار|دولارات|ليرة|ليرات|سورية|سوري|يورو|usd|syp|eur|[$€])", " ");
            title=title.replaceAll("^(دفعت|صرفت|صرفنا|اشتريت|شراء|قبضت|استلمت|دخلني|دخل|مبلغ|من|على)\\s+", "").trim();
            if(title.isEmpty())title="عملية مالية";
            String category=category(title+" "+part,kind);
            result.add(new Store.Transaction(0,kind,title,category,currency,amount,today));
        }
        return result;
    }
    private static String normalizeDigits(String s) {
        StringBuilder b=new StringBuilder();
        for(char c:s.toCharArray()) {
            if(c>='٠'&&c<='٩')b.append((char)('0'+c-'٠'));
            else if(c>='۰'&&c<='۹')b.append((char)('0'+c-'۰'));
            else if(c=='٫')b.append('.'); else b.append(c);
        }
        return b.toString();
    }
    static String category(String phrase,String kind) {
        String t=phrase.toLowerCase(Locale.ROOT);
        if(kind.equals("income")) {
            if(has(t,"راتب","معاش","وظيفة"))return "راتب";
            if(has(t,"رندر","تصميم","مخطط","مشروع","عميل","زبون","استشارة","هندسة","تصيير","أوتوكاد"))return "عمل حر";
            if(has(t,"هدية","عطية","مكافأة"))return "هدايا ومكافآت";
            if(has(t,"بيع","بعت","مبيعات"))return "مبيعات";
            return "دخل آخر";
        }
        if(has(t,"بنزين","مازوت","تكسي","تاكسي","باص","نقل","مواصلات","سيارة","سرفيس","محروقات"))return "مواصلات";
        if(has(t,"أكل","اكل","طعام","مطعم","سندويش","سندويشة","فطور","غداء","عشاء","غدا","عشا","بقالية","خضرة","سوبر"))return "طعام";
        if(has(t,"قهوة","نسكافيه","شاي","عصير","كوفي","مشروبات","كافيه"))return "مشروبات ومقاهي";
        if(has(t,"إيجار","ايجار","كهربا","كهرباء","ماء","انترنت","إنترنت","نت","فاتورة","فواتير","غاز"))return "سكن وفواتير";
        if(has(t,"مشفى","طبيب","دكتور","دواء","صيدلية","علاج","كشفية"))return "صحة";
        if(has(t,"جامعة","كتاب","كتب","دورة","كورس","تعليم","قرطاسية","طباعة"))return "تعليم";
        if(has(t,"نادي","حديد","mma","رياضة","اشتراك","مسبح"))return "رياضة";
        if(has(t,"لبس","ملابس","حذاء","جاكيت","قميص"))return "ملابس";
        if(has(t,"سينما","لعبة","فيفا","طلعة","تسلية","ترفيه"))return "ترفيه";
        return "غير مصنف";
    }
    private static boolean has(String s,String... items) {
        for(String x:items)if(s.contains(x))return true;
        return false;
    }
    private MoneyParser() { }
}
