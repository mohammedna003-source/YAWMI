package com.yawmi.offline;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.os.Build;
import android.provider.Settings;

public final class PrayerAlarmReceiver extends BroadcastReceiver {
    private static final String CHANNEL="yawmi_prayer_alarm_1";
    @Override public void onReceive(Context context,Intent intent) {
        if(PrayerScheduler.ACTION_REFRESH.equals(intent.getAction())) {
            PrayerScheduler.schedule(context);return;
        }
        if(!PrayerScheduler.ACTION_PRAYER.equals(intent.getAction()))return;
        if(Build.VERSION.SDK_INT>=33&&context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
            !=PackageManager.PERMISSION_GRANTED)return;
        NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) {
            NotificationChannel c=new NotificationChannel(CHANNEL,"منبه الصلاة",NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("تنبيه قبل موعد الأذان");
            c.setSound(Settings.System.DEFAULT_ALARM_ALERT_URI,new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            c.enableVibration(true);manager.createNotificationChannel(c);
        }
        String name=intent.getStringExtra("prayer"),city=intent.getStringExtra("city");
        int lead=intent.getIntExtra("lead",15);
        String title=lead>0?"اقترب أذان "+name:"حان موعد أذان "+name;
        String message=lead>0?"باقي "+lead+" دقيقة على الأذان في "+city:"حان وقت الصلاة في "+city;
        PendingIntent open=PendingIntent.getActivity(context,0,
            new Intent(context,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(context,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(message).setAutoCancel(true)
            .setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_HIGH)
            .setContentIntent(open).build();
        manager.notify(intent.getIntExtra("id",1),n);
    }
}
