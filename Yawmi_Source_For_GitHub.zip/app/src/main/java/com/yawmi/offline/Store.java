package com.yawmi.offline;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class Store extends SQLiteOpenHelper {
    public static class Task {
        public long id; public String text, date; public boolean done;
        public Task(long id, String text, String date, boolean done) {
            this.id=id; this.text=text; this.date=date; this.done=done;
        }
    }
    public static class Transaction {
        public long id; public String type, description, category, currency, date;
        public double amount;
        public Transaction(long id, String type, String description, String category,
                           String currency, double amount, String date) {
            this.id=id; this.type=type; this.description=description; this.category=category;
            this.currency=currency; this.amount=amount; this.date=date;
        }
    }
    public Store(Context ctx) { super(ctx, "yawmi.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, due_date TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE INDEX idx_tasks_date ON tasks(due_date)");
        db.execSQL("CREATE TABLE money (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, title TEXT NOT NULL, category TEXT NOT NULL, currency TEXT NOT NULL, amount REAL NOT NULL, entry_date TEXT NOT NULL)");
        db.execSQL("CREATE INDEX idx_money_date ON money(entry_date)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    public long addTask(String title, String dueDate) {
        ContentValues v=new ContentValues(); v.put("title", title); v.put("due_date", dueDate); v.put("done", 0);
        return getWritableDatabase().insertOrThrow("tasks", null, v);
    }
    public void setTaskDone(long id, boolean done) {
        ContentValues v=new ContentValues(); v.put("done", done?1:0);
        getWritableDatabase().update("tasks", v, "id=?", new String[]{String.valueOf(id)});
    }
    public void deleteTask(long id) { getWritableDatabase().delete("tasks", "id=?", new String[]{String.valueOf(id)}); }
    public List<Task> tasks(String date) {
        List<Task> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().query("tasks", new String[]{"id","title","due_date","done"},
                "due_date=?", new String[]{date}, null, null, "done ASC, id DESC")) {
            while(c.moveToNext()) out.add(new Task(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3)==1));
        }
        return out;
    }
    public long addMoney(Transaction t) {
        ContentValues v=new ContentValues();v.put("kind",t.type);v.put("title",t.description);
        v.put("category",t.category);v.put("currency",t.currency);v.put("amount",t.amount);
        v.put("entry_date",t.date);
        return getWritableDatabase().insertOrThrow("money",null,v);
    }
    public void deleteMoney(long id) { getWritableDatabase().delete("money", "id=?", new String[]{String.valueOf(id)}); }
    public List<Transaction> money(String datePrefix, int limit) {
        List<Transaction> out=new ArrayList<>();
        String where=(datePrefix==null)?null:"entry_date LIKE ?";
        String[] args=(datePrefix==null)?null:new String[]{datePrefix+"%"};
        try(Cursor c=getReadableDatabase().query("money",new String[]{"id","kind","title","category","currency","amount","entry_date"},
                where,args,null,null,"entry_date DESC,id DESC",limit>0?String.valueOf(limit):null)) {
            while(c.moveToNext()) out.add(new Transaction(c.getLong(0),c.getString(1),c.getString(2),
                    c.getString(3),c.getString(4),c.getDouble(5),c.getString(6)));
        }
        return out;
    }
    public JSONObject exportAll(SharedPreferences prefs) throws Exception {
        JSONObject root=new JSONObject();root.put("format","yawmi-backup-v1");
        root.put("exported_at",java.time.Instant.now().toString());
        JSONArray tasks=new JSONArray();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT title,due_date,done FROM tasks ORDER BY id",null)) {
            while(c.moveToNext()) tasks.put(new JSONObject().put("title",c.getString(0)).put("date",c.getString(1)).put("done",c.getInt(2)));
        }
        JSONArray entries=new JSONArray();
        for(Transaction t: money(null,0)) entries.put(new JSONObject().put("type",t.type)
            .put("description",t.description).put("category",t.category).put("currency",t.currency)
            .put("amount",t.amount).put("date",t.date));
        JSONObject settings=new JSONObject();
        settings.put("city",prefs.getInt("city",0));settings.put("remind",prefs.getInt("remind",15));
        settings.put("currency",prefs.getString("currency","SYP"));
        for(String prayer:PrayerTimes.NAMES_EN) settings.put("offset_"+prayer,prefs.getInt("offset_"+prayer,0));
        return root.put("tasks",tasks).put("money",entries).put("settings",settings);
    }
    public void importAll(JSONObject root,SharedPreferences prefs) throws Exception {
        if(!"yawmi-backup-v1".equals(root.getString("format"))) throw new IllegalArgumentException("نسخة احتياطية غير مدعومة");
        JSONArray tasks=root.getJSONArray("tasks"), money=root.getJSONArray("money");
        // Parse and validate before replacing any user data.
        List<Task> checkedTasks=new ArrayList<>(); List<Transaction> checkedMoney=new ArrayList<>();
        for(int i=0;i<tasks.length();i++) {
            JSONObject t=tasks.getJSONObject(i); String date=t.getString("date");LocalDate.parse(date);
            checkedTasks.add(new Task(0,t.getString("title"),date,t.getInt("done")!=0));
        }
        for(int i=0;i<money.length();i++) {
            JSONObject t=money.getJSONObject(i);String date=t.getString("date");LocalDate.parse(date);
            double amount=t.getDouble("amount");
            if(!Double.isFinite(amount)||amount<=0)throw new IllegalArgumentException("المبلغ غير صالح");
            checkedMoney.add(new Transaction(0,t.getString("type"),t.getString("description"),
                t.getString("category"),t.getString("currency"),amount,date));
        }
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            db.delete("tasks",null,null);db.delete("money",null,null);
            for(Task t:checkedTasks) {
                ContentValues v=new ContentValues();v.put("title",t.text);v.put("due_date",t.date);v.put("done",t.done?1:0);
                db.insertOrThrow("tasks",null,v);
            }
            for(Transaction t:checkedMoney) {
                ContentValues v=new ContentValues();v.put("kind",t.type);v.put("title",t.description);
                v.put("category",t.category);v.put("currency",t.currency);v.put("amount",t.amount);v.put("entry_date",t.date);
                db.insertOrThrow("money",null,v);
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        JSONObject s=root.optJSONObject("settings");
        if(s!=null){
            SharedPreferences.Editor e=prefs.edit();
            e.putInt("city",Math.max(0,Math.min(PrayerTimes.CITIES.length-1,s.optInt("city",0))));
            e.putInt("remind",Math.max(0,Math.min(60,s.optInt("remind",15))));
            String cur=s.optString("currency","SYP");e.putString("currency",cur.equals("USD")||cur.equals("EUR")?cur:"SYP");
            for(String p:PrayerTimes.NAMES_EN)e.putInt("offset_"+p,Math.max(-120,Math.min(120,s.optInt("offset_"+p,0))));
            e.apply();
        }
    }
}
