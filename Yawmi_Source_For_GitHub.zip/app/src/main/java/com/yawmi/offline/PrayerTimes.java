package com.yawmi.offline;

import android.content.SharedPreferences;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.time.ZoneId;

/**
 * Approximate astronomical timings using solar coordinates and MWL (Fajr 18°, Isha 17°),
 * standard Asr shadow factor 1. These are NOT a mosque's official published schedule.
 * City time zones are used even when the handset is set to another zone.
 */
public final class PrayerTimes {
    public static final String[] NAMES_AR={"الفجر","الظهر","العصر","المغرب","العشاء"};
    public static final String[] NAMES_EN={"fajr","dhuhr","asr","maghrib","isha"};
    public static final class City {
        public final String name,zone; public final double lat,lon;
        City(String name,double lat,double lon,String zone){this.name=name;this.lat=lat;this.lon=lon;this.zone=zone;}
    }
    public static final City[] CITIES={
        new City("حلب",36.2021,37.1343,"Asia/Damascus"),
        new City("دمشق",33.5138,36.2765,"Asia/Damascus"),
        new City("حمص",34.7308,36.7090,"Asia/Damascus"),
        new City("حماة",35.1318,36.7578,"Asia/Damascus"),
        new City("إدلب",35.9306,36.6339,"Asia/Damascus"),
        new City("اللاذقية",35.5317,35.7901,"Asia/Damascus"),
        new City("طرطوس",34.8959,35.8866,"Asia/Damascus"),
        new City("دبي",25.2048,55.2708,"Asia/Dubai"),
        new City("أمستردام",52.3676,4.9041,"Europe/Amsterdam"),
        new City("إسطنبول",41.0082,28.9784,"Europe/Istanbul"),
        new City("الرياض",24.7136,46.6753,"Asia/Riyadh"),
        new City("القاهرة",30.0444,31.2357,"Africa/Cairo")
    };
    public static ZonedDateTime[] calculate(LocalDate day,City city,SharedPreferences prefs) {
        double tz=day.atTime(12,0).atZone(ZoneId.of(city.zone)).getOffset().getTotalSeconds()/3600.0;
        // Julian date at 00:00 UTC, evaluated close to local noon for consistency.
        double jd=day.toEpochDay()+2440587.5;
        Sun sun=sunAt(jd+0.5-city.lon/360.0);
        double noon=12.0-sun.eqTime-city.lon/15.0+tz;
        double sunriseAngle=-0.833;
        double fajr=noon-hourAngle(-18.0,city.lat,sun.dec);
        double dhuhr=noon;
        double asrAltitude=Math.toDegrees(Math.atan(1.0/(1.0+Math.tan(Math.toRadians(Math.abs(city.lat-sun.dec))))));
        double asr=noon+hourAngle(asrAltitude,city.lat,sun.dec);
        double maghrib=noon+hourAngle(sunriseAngle,city.lat,sun.dec);
        double isha=noon+hourAngle(-17.0,city.lat,sun.dec);
        double[] hours={fajr,dhuhr,asr,maghrib,isha};
        ZonedDateTime[] result=new ZonedDateTime[5];
        for(int i=0;i<5;i++) {
            long minutes=Math.round(hours[i]*60.0)+prefs.getInt("offset_"+NAMES_EN[i],0);
            result[i]=day.atStartOfDay(ZoneId.of(city.zone)).plusMinutes(minutes);
        }
        return result;
    }
    private static final class Sun {
        final double dec,eqTime; Sun(double dec,double eqTime){this.dec=dec;this.eqTime=eqTime;}
    }
    private static Sun sunAt(double jd) {
        double d=jd-2451545.0;
        double g=Math.toRadians(mod(357.529+0.98560028*d,360));
        double q=mod(280.459+0.98564736*d,360);
        double l=Math.toRadians(mod(q+1.915*Math.sin(g)+0.020*Math.sin(2*g),360));
        double e=Math.toRadians(23.439-0.00000036*d);
        double ra=mod(Math.toDegrees(Math.atan2(Math.cos(e)*Math.sin(l),Math.cos(l)))/15.0,24.0);
        double dec=Math.toDegrees(Math.asin(Math.sin(e)*Math.sin(l)));
        double eq=q/15.0-ra;
        if(eq>12)eq-=24; else if(eq< -12)eq+=24;
        return new Sun(dec,eq);
    }
    private static double hourAngle(double alt,double lat,double dec) {
        double latR=Math.toRadians(lat),decR=Math.toRadians(dec),altR=Math.toRadians(alt);
        double cosine=(Math.sin(altR)-Math.sin(latR)*Math.sin(decR))/(Math.cos(latR)*Math.cos(decR));
        cosine=Math.max(-1,Math.min(1,cosine));
        return Math.toDegrees(Math.acos(cosine))/15.0;
    }
    private static double mod(double a,double b){return (a%b+b)%b;}
    private PrayerTimes(){ }
}
