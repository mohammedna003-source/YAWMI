package com.yawmi.offline;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(13,20,35), CARD=Color.rgb(23,33,52);
    private static final int ACCENT=Color.rgb(63,224,194), WHITE=Color.rgb(239,246,251);
    private static final int MUTED=Color.rgb(155,172,193), LINE=Color.rgb(46,61,81);
    private static final int WARNING=Color.rgb(255,185,109);
    private static final DateTimeFormatter TIME=DateTimeFormatter.ofPattern("HH:mm",Locale.US);
    private static final int CREATE_BACKUP=7001, OPEN_BACKUP=7002, NOTIFY_PERMISSION=7003;
    private static final String[] TABS={"الرئيسية","المهام","الصلاة","المالية"};
    private Store store;
    private SharedPreferences prefs;
    private LinearLayout page,outer;
    private int tab=0;
    private LocalDate taskDate=LocalDate.now().plusDays(1);
    private String financeCurrency="SYP";

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        store=new Store(this);prefs=getSharedPreferences("yawmi_prefs",MODE_PRIVATE);
        financeCurrency=prefs.getString("currency","SYP");
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        PrayerScheduler.schedule(this);render();
    }
    @Override protected void onResume(){ super.onResume();if(prefs!=null)PrayerScheduler.schedule(this); }
    private int d(float x){return (int)(getResources().getDisplayMetrics().density*x+0.5f);}
    private GradientDrawable shape(int color,int radius){
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(d(radius));return g;
    }
    private GradientDrawable outline(int color,int stroke,int radius){
        GradientDrawable g=shape(color,radius);g.setStroke(d(1),stroke);return g;
    }
    private LinearLayout col(){ LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l; }
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}
    private LinearLayout.LayoutParams lp(int width,int height){return new LinearLayout.LayoutParams(width<0?width:d(width),height<0?height:d(height));}
    private LinearLayout.LayoutParams margin(int top,int bottom){LinearLayout.LayoutParams p=lp(-1,-2);p.setMargins(0,d(top),0,d(bottom));return p;}
    private TextView text(String value,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        if(bold)t.setTypeface(null,Typeface.BOLD);t.setIncludeFontPadding(true);return t;
    }
    private Button button(String title,boolean primary){
        Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextSize(14);
        b.setTextColor(primary?BG:WHITE);b.setTypeface(null,Typeface.BOLD);
        b.setPadding(d(12),d(7),d(12),d(7));b.setMinHeight(d(44));b.setMinWidth(0);
        b.setBackground(primary?shape(ACCENT,13):outline(CARD,LINE,13));return b;
    }
    private EditText input(String hint,int minLines){
        EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(MUTED);e.setTextColor(WHITE);
        e.setTextSize(15);e.setPadding(d(15),d(10),d(15),d(10));e.setBackground(outline(BG,LINE,12));
        e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        e.setMinLines(minLines);e.setGravity(Gravity.TOP|Gravity.RIGHT);
        e.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return e;
    }
    private LinearLayout card(){
        LinearLayout l=col();l.setPadding(d(16),d(15),d(16),d(15));l.setBackground(outline(CARD,LINE,18));
        page.addView(l,margin(8,8));return l;
    }
    private void divider(LinearLayout target){ View v=new View(this);v.setBackgroundColor(LINE);target.addView(v,margin(11,11)); }
    private void section(String title,String subtitle){
        page.addView(text(title,23,WHITE,true),margin(15,3));
        if(subtitle!=null)page.addView(text(subtitle,13,MUTED,false),margin(2,10));
    }
    private void label(LinearLayout target,String txt,int size,int color,boolean bold){target.addView(text(txt,size,color,bold),margin(3,3));}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void render(){
        outer=col();outer.setBackgroundColor(BG);outer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        if(Build.VERSION.SDK_INT>=35){
            outer.setOnApplyWindowInsetsListener((v,insets)->{
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);return insets;
            });
        }
        LinearLayout header=col();header.setPadding(d(20),d(15),d(20),d(12));
        header.addView(text("يـومـي  /  YAWMI",13,ACCENT,true));
        header.addView(text("رتّب يومك بطريقتك",20,WHITE,true),margin(5,0));
        outer.addView(header,lp(-1,-2));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        page=col();page.setPadding(d(18),d(5),d(18),d(20));scroll.addView(page);
        outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(tab==0)dashboard();else if(tab==1)tasksPage();else if(tab==2)prayerPage();else financePage();
        LinearLayout nav=row();nav.setPadding(d(6),d(8),d(6),d(9));nav.setBackgroundColor(CARD);
        for(int i=0;i<TABS.length;i++){
            final int index=i;TextView b=text(TABS[i],13,i==tab?ACCENT:MUTED,i==tab);
            b.setGravity(Gravity.CENTER);b.setPadding(d(3),d(10),d(3),d(10));
            b.setBackground(i==tab?shape(BG,10):shape(CARD,10));
            nav.addView(b,new LinearLayout.LayoutParams(0,d(44),1));
            b.setOnClickListener(v->{tab=index;render();});
        }
        outer.addView(nav,lp(-1,-2));setContentView(outer);
    }
    private void dashboard(){
        LocalDate today=LocalDate.now();
        section("صباح الخير ☀",today.getDayOfWeek().getDisplayName(TextStyle.FULL,new Locale("ar"))+" • "+today);
        List<Store.Task> todayTasks=store.tasks(today.toString());
        int done=0;for(Store.Task t:todayTasks)if(t.done)done++;
        LinearLayout c=card();label(c,"إنجاز اليوم",14,MUTED,false);
        label(c,done+" / "+todayTasks.size()+" مهام مكتملة",25,WHITE,true);
        LinearLayout r=row();TextView upcoming=text("مهام بكرا: "+store.tasks(today.plusDays(1).toString()).size(),14,ACCENT,true);
        r.addView(upcoming,new LinearLayout.LayoutParams(0,-2,1));Button add=button("+ مهمة جديدة",true);
        add.setOnClickListener(v->addTaskDialog());r.addView(add,lp(-2,-2));c.addView(r,margin(8,0));

        PrayerTimes.City city=city();ZonedDateTime now=ZonedDateTime.now(ZoneId.of(city.zone));
        ZonedDateTime[] times=PrayerTimes.calculate(now.toLocalDate(),city,prefs);
        ZonedDateTime next=null;int idx=0;
        for(int i=0;i<5;i++)if(times[i].isAfter(now)){next=times[i];idx=i;break;}
        if(next==null){next=PrayerTimes.calculate(now.toLocalDate().plusDays(1),city,prefs)[0];idx=0;}
        long minutes=Math.max(0,Duration.between(now,next).toMinutes());
        c=card();label(c,"الصلاة القادمة • "+city.name,14,MUTED,false);
        label(c,PrayerTimes.NAMES_AR[idx]+" — "+next.format(TIME),24,ACCENT,true);
        label(c,"بعد "+(minutes/60)+" ساعة و"+(minutes%60)+" دقيقة تقريباً",14,WHITE,false);
        Button prayers=button("عرض المواقيت والتنبيهات ←",false);
        prayers.setOnClickListener(v->{tab=2;render();});c.addView(prayers,margin(12,0));

        List<Store.Transaction> current=store.money(today.toString().substring(0,7),0);
        c=card();label(c,"حسابات الشهر الحالي",15,WHITE,true);
        for(String currency:new String[]{"SYP","USD","EUR"}){
            double income=0,expense=0;
            for(Store.Transaction t:current)if(t.currency.equals(currency)){
                if(t.type.equals("income"))income+=t.amount;else expense+=t.amount;
            }
            if(income>0||expense>0){
                label(c,"● "+currencyLabel(currency)+"  |  دخل "+money(income)+"  •  مصروف "+money(expense),13,MUTED,false);
                label(c,"الصافي: "+money(income-expense)+" "+currencyLabel(currency),17,ACCENT,true);
            }
        }
        if(current.isEmpty())label(c,"ما في عمليات مالية مسجلة لهذا الشهر بعد.",14,MUTED,false);
        Button finance=button("+ تسجيل صرف أو مقبوض",true);finance.setOnClickListener(v->{tab=3;render();});c.addView(finance,margin(10,2));
        c=card();label(c,"خصوصية كاملة",16,ACCENT,true);
        label(c,"كل بياناتك محفوظة على جهازك فقط. التطبيق ما بيحتاج حساب أو إنترنت.",14,WHITE,false);
        LinearLayout rr=row();Button export=button("نسخة احتياطية",false);export.setOnClickListener(v->exportBackup());
        Button load=button("استعادة نسخة",false);load.setOnClickListener(v->importBackup());
        rr.addView(export,new LinearLayout.LayoutParams(0,d(48),1));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,d(48),1);p.setMargins(d(8),0,0,0);rr.addView(load,p);
        c.addView(rr,margin(12,0));
    }
    private void tasksPage(){
        section("مهامي اليومية","اكتب اللي بدك تعمله بكرا، وعلّم كل مهمة بتنجزها.");
        LinearLayout c=card();
        LinearLayout r=row();TextView date=text("📅  "+taskDate,17,WHITE,true);
        r.addView(date,new LinearLayout.LayoutParams(0,-2,1));
        Button change=button("تغيير اليوم",false);change.setOnClickListener(v->chooseTaskDate());r.addView(change,lp(-2,-2));c.addView(r);
        Button add=button("+ إضافة مهمة",true);add.setOnClickListener(v->addTaskDialog());c.addView(add,margin(12,0));
        List<Store.Task> tasks=store.tasks(taskDate.toString());
        c=card();int completed=0;for(Store.Task t:tasks)if(t.done)completed++;
        label(c,"قائمة المهام  •  "+completed+" / "+tasks.size()+" منجزة",17,WHITE,true);
        if(tasks.isEmpty())label(c,"ما في مهام لهاليوم. اضغط إضافة مهمة وبلّش ✨",14,MUTED,false);
        for(Store.Task t:tasks){
            divider(c);LinearLayout line=row();
            CheckBox check=new CheckBox(this);check.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));
            check.setChecked(t.done);line.addView(check,lp(40,44));
            TextView title=text(t.text,15,t.done?MUTED:WHITE,false);
            if(t.done)title.setPaintFlags(title.getPaintFlags()|android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
            line.addView(title,new LinearLayout.LayoutParams(0,-2,1));
            Button delete=button("حذف",false);delete.setOnClickListener(v->new AlertDialog.Builder(this)
                .setTitle("حذف المهمة؟").setMessage(t.text).setPositiveButton("حذف",(dialog,which)->{store.deleteTask(t.id);render();})
                .setNegativeButton("إلغاء",null).show());line.addView(delete,lp(-2,43));c.addView(line);
            check.setOnCheckedChangeListener((btn,checked)->{store.setTaskDone(t.id,checked);render();});
        }
        LinearLayout quick=card();label(quick,"تنقل سريع",15,WHITE,true);
        LinearLayout nav=row();Button today=button("اليوم",false);today.setOnClickListener(v->{taskDate=LocalDate.now();render();});
        Button tomorrow=button("بكرا",false);tomorrow.setOnClickListener(v->{taskDate=LocalDate.now().plusDays(1);render();});
        nav.addView(today,new LinearLayout.LayoutParams(0,d(46),1));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,d(46),1);p.setMargins(d(8),0,0,0);nav.addView(tomorrow,p);quick.addView(nav);
    }
    private void chooseTaskDate(){
        DatePickerDialog dlg=new DatePickerDialog(this,(picker,year,month,day)->{
            taskDate=LocalDate.of(year,month+1,day);render();
        },taskDate.getYear(),taskDate.getMonthValue()-1,taskDate.getDayOfMonth());dlg.show();
    }
    private void addTaskDialog(){
        LinearLayout area=col();area.setPadding(d(20),d(12),d(20),0);
        EditText name=input("مثلاً: تسليم مخططات المشروع",2);area.addView(name,lp(-1,-2));
        final LocalDate[] selected={taskDate};
        Button date=button("التاريخ: "+selected[0],false);area.addView(date,margin(12,0));
        date.setOnClickListener(v->new DatePickerDialog(this,(picker,y,m,day)->{
            selected[0]=LocalDate.of(y,m+1,day);date.setText("التاريخ: "+selected[0]);
        },selected[0].getYear(),selected[0].getMonthValue()-1,selected[0].getDayOfMonth()).show());
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("مهمة جديدة")
            .setView(area).setPositiveButton("إضافة",null).setNegativeButton("إلغاء",null).create();
        dlg.setOnShowListener(ignored->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String txt=name.getText().toString().trim();if(txt.isEmpty()){name.setError("اكتب اسم المهمة");return;}
            store.addTask(txt,selected[0].toString());taskDate=selected[0];dlg.dismiss();render();
        }));dlg.show();
    }
    private PrayerTimes.City city(){
        int idx=Math.max(0,Math.min(PrayerTimes.CITIES.length-1,prefs.getInt("city",0)));
        return PrayerTimes.CITIES[idx];
    }
    private void prayerPage(){
        section("مواقيت الصلاة","مواقيت محسوبة بدون إنترنت، مع تنبيه قبل الأذان.");
        LinearLayout settings=card();label(settings,"المدينة الحالية",14,MUTED,false);
        LinearLayout line=row();TextView current=text("📍  "+city().name,22,WHITE,true);
        line.addView(current,new LinearLayout.LayoutParams(0,-2,1));Button change=button("تغيير",false);
        change.setOnClickListener(v->selectCity());line.addView(change,lp(-2,-2));settings.addView(line);
        divider(settings);
        int lead=prefs.getInt("remind",15);
        LinearLayout r=row();TextView leadTxt=text("🔔  قبل الأذان بـ "+lead+" دقيقة",16,WHITE,true);
        r.addView(leadTxt,new LinearLayout.LayoutParams(0,-2,1));Button set=button("تعديل",false);
        set.setOnClickListener(v->selectLead());r.addView(set,lp(-2,-2));settings.addView(r);
        divider(settings);
        boolean exact=PrayerScheduler.exactAllowed(this);
        boolean notified=Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;
        label(settings,(exact&&notified?"● التنبيهات مفعّلة":"● فعّل صلاحيات التنبيهات"),15,exact&&notified?ACCENT:WARNING,true);
        Button permission=button("ضبط صلاحيات المنبّه",true);permission.setOnClickListener(v->requestPrayerPermissions());
        settings.addView(permission,margin(9,0));
        label(settings,"تنبيه صوتي مرتفع عبر إشعارات النظام. لضمان الدقة، اسمح بـ«المنبهات والتذكيرات» وبالإشعارات.",12,MUTED,false);
        PrayerTimes.City city=city();LocalDate today=LocalDate.now(ZoneId.of(city.zone));
        ZonedDateTime[] times=PrayerTimes.calculate(today,city,prefs);
        LinearLayout list=card();label(list,"مواقيت اليوم • "+today,17,WHITE,true);
        for(int i=0;i<5;i++){
            final int prayerIndex=i;
            divider(list);LinearLayout a=row();
            TextView name=text(PrayerTimes.NAMES_AR[i],17,WHITE,true);
            a.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            TextView time=text(times[i].format(TIME),18,ACCENT,true);a.addView(time,lp(78,-2));
            Button tune=button("± د",false);tune.setOnClickListener(v->adjustPrayer(prayerIndex));
            a.addView(tune,lp(60,40));list.addView(a);
        }
        LinearLayout note=card();label(note,"مهم قبل الاعتماد على التوقيت",15,WARNING,true);
        label(note,"التوقيتات فلكية تقريبية (الفجر 18° والعشاء 17°) وقد تختلف عن تقويم الأوقاف أو مسجد الحارة. عدّل دقائق كل صلاة من زر ± د حتى تتطابق مع جامعك.",13,WHITE,false);
        label(note,"المدينة الافتراضية حلب. البيانات لا تحتاج GPS ولا إنترنت.",12,MUTED,false);
    }
    private void selectCity(){
        String[] options=new String[PrayerTimes.CITIES.length];
        for(int i=0;i<options.length;i++)options[i]=PrayerTimes.CITIES[i].name;
        new AlertDialog.Builder(this).setTitle("اختار مدينتك")
            .setSingleChoiceItems(options,prefs.getInt("city",0),(dialog,which)->{
                prefs.edit().putInt("city",which).apply();PrayerScheduler.schedule(this);dialog.dismiss();render();
            }).setNegativeButton("إلغاء",null).show();
    }
    private void selectLead(){
        int[] numbers={0,5,10,15,20,30,45,60};String[] options=new String[numbers.length];
        for(int i=0;i<options.length;i++)options[i]=numbers[i]==0?"عند الأذان":numbers[i]+" دقيقة قبله";
        new AlertDialog.Builder(this).setTitle("متى أوصلك تنبيه الصلاة؟")
            .setItems(options,(dialog,index)->{
                prefs.edit().putInt("remind",numbers[index]).apply();PrayerScheduler.schedule(this);render();
            }).show();
    }
    private void adjustPrayer(int idx){
        String key="offset_"+PrayerTimes.NAMES_EN[idx];
        EditText edit=input("مثلاً +5 أو -3",1);edit.setSingleLine(true);
        edit.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_SIGNED);
        edit.setText(String.valueOf(prefs.getInt(key,0)));
        LinearLayout holder=col();holder.setPadding(d(22),d(8),d(22),d(8));holder.addView(edit);
        new AlertDialog.Builder(this).setTitle("تعديل صلاة "+PrayerTimes.NAMES_AR[idx])
            .setMessage("عدد دقائق الإضافة أو الخصم عن الوقت الفلكي (من -120 إلى +120)")
            .setView(holder).setPositiveButton("حفظ",(dialog,which)->{
                try{
                    int minutes=Integer.parseInt(edit.getText().toString().trim());
                    if(minutes< -120||minutes>120){toast("القيمة بين -120 و120 دقيقة");return;}
                    prefs.edit().putInt(key,minutes).apply();PrayerScheduler.schedule(this);render();
                }catch(Exception ex){toast("اكتب عدد دقائق صحيح");}
            }).setNegativeButton("إلغاء",null).show();
    }
    private void requestPrayerPermissions(){
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFY_PERMISSION);return;
        }
        if(Build.VERSION.SDK_INT>=31&&!PrayerScheduler.exactAllowed(this)){
            try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:"+getPackageName())));}
            catch(Exception ex){toast("افتح إعدادات التطبيق وفعّل المنبهات والتذكيرات.");}
        }else{PrayerScheduler.schedule(this);toast("تم ضبط تنبيهات الصلاة");render();}
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if(requestCode==NOTIFY_PERMISSION){
            if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED) requestPrayerPermissions();
            else toast("بدون صلاحية الإشعارات ما رح توصلك تنبيهات الصلاة");
            render();
        }
    }
    private void financePage(){
        section("دفتري المالي","اكتب مبلغك بجملة عادية، والتطبيق يصنّفه محلياً.");
        LinearLayout c=card();label(c,"اكتب العملية أو أكثر",16,WHITE,true);
        EditText description=input("مثال: دفعت 50 ألف بنزين، و30 ألف أكل، و15 ألف قهوة",3);
        c.addView(description,margin(9,9));
        LinearLayout line=row();label(line,"عملة افتراضية عند عدم ذكرها:",13,MUTED,false);
        Button currency=button(financeCurrency,false);currency.setOnClickListener(v->{
            String[] choices={"SYP","USD","EUR"};
            new AlertDialog.Builder(this).setTitle("العملة الافتراضية")
                .setItems(choices,(dialog,which)->{
                    financeCurrency=choices[which];prefs.edit().putString("currency",financeCurrency).apply();
                    currency.setText(financeCurrency);
                }).show();
        });line.addView(currency,lp(-2,44));c.addView(line,margin(4,9));
        LinearLayout actions=row();Button expense=button("− سجّل مصروف",true);
        Button income=button("+ سجّل مقبوض",false);
        expense.setOnClickListener(v->previewMoney(description,"expense"));
        income.setOnClickListener(v->previewMoney(description,"income"));
        actions.addView(expense,new LinearLayout.LayoutParams(0,d(52),1));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,d(52),1);ap.setMargins(d(8),0,0,0);
        actions.addView(income,ap);c.addView(actions);
        label(c,"التصنيف تلقائي بقواعد ذكية محلية، وليس نموذج ذكاء اصطناعي سحابياً. بتراجع العمليات قبل حفظها.",12,MUTED,false);

        List<Store.Transaction> month=store.money(LocalDate.now().toString().substring(0,7),0);
        c=card();label(c,"ملخص الشهر الحالي",17,WHITE,true);
        for(String unit:new String[]{"SYP","USD","EUR"}){
            double expenseSum=0,incomeSum=0;
            for(Store.Transaction t:month)if(t.currency.equals(unit)){
                if(t.type.equals("expense"))expenseSum+=t.amount;else incomeSum+=t.amount;
            }
            if(expenseSum==0&&incomeSum==0)continue;
            divider(c);label(c,currencyLabel(unit),15,ACCENT,true);
            label(c,"المقبوضات  +"+money(incomeSum)+"     المصروفات  −"+money(expenseSum),13,WHITE,false);
            label(c,"الصافي   "+money(incomeSum-expenseSum)+" "+unit,18,WHITE,true);
        }
        if(month.isEmpty())label(c,"ما في تسجيلات للشهر الحالي.",14,MUTED,false);
        Map<String,Double> totals=new HashMap<>();
        for(Store.Transaction t:month)if(t.type.equals("expense")){
            String key=t.category+" ("+t.currency+")";totals.put(key,totals.getOrDefault(key,0.0)+t.amount);
        }
        if(!totals.isEmpty()){
            LinearLayout cats=card();label(cats,"المصاريف حسب التصنيف",17,WHITE,true);
            List<Map.Entry<String,Double>> sorted=new ArrayList<>(totals.entrySet());
            sorted.sort((a,b)->Double.compare(b.getValue(),a.getValue()));
            for(Map.Entry<String,Double> entry:sorted){divider(cats);
                label(cats,entry.getKey()+"  •  "+money(entry.getValue()),14,WHITE,false);
            }
        }
        c=card();label(c,"آخر العمليات",17,WHITE,true);
        List<Store.Transaction> items=store.money(null,40);
        if(items.isEmpty())label(c,"اكتب أول عملية بالأعلى.",14,MUTED,false);
        for(Store.Transaction t:items){divider(c);LinearLayout r=row();LinearLayout details=col();
            label(details,(t.type.equals("income")?"↗ ":"↘ ")+t.description,15,WHITE,true);
            label(details,t.category+" • "+t.date,12,MUTED,false);
            r.addView(details,new LinearLayout.LayoutParams(0,-2,1));
            LinearLayout right=col();label(right,(t.type.equals("income")?"+":"−")+money(t.amount),15,
                t.type.equals("income")?ACCENT:WARNING,true);
            label(right,t.currency,12,MUTED,false);r.addView(right,lp(-2,-2));
            Button del=button("×",false);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف العملية؟")
                .setMessage(t.description+" — "+money(t.amount)+" "+t.currency)
                .setPositiveButton("حذف",(dia,which)->{store.deleteMoney(t.id);render();})
                .setNegativeButton("إلغاء",null).show());
            LinearLayout.LayoutParams dp=lp(43,43);dp.setMargins(d(7),0,0,0);r.addView(del,dp);c.addView(r);
        }
    }
    private void previewMoney(EditText entry,String kind){
        List<Store.Transaction> parsed=MoneyParser.parse(entry.getText().toString(),kind,financeCurrency);
        if(parsed.isEmpty()){
            new AlertDialog.Builder(this).setTitle("ما لقيت مبلغ واضح")
                .setMessage("جرّب تكتب مثلاً: 50 ألف بنزين، أو 200 دولار تصميم رندر. لازم يكون في رقم.")
                .setPositiveButton("فهمت",null).show();return;
        }
        StringBuilder message=new StringBuilder();
        for(Store.Transaction t:parsed)message.append("• ").append(t.description).append(" ← ")
            .append(t.category).append("\n   ").append(money(t.amount)).append(" ").append(t.currency).append("\n\n");
        new AlertDialog.Builder(this).setTitle(kind.equals("income")?"تأكيد المقبوضات":"تأكيد المصروفات")
            .setMessage(message.toString().trim()).setPositiveButton("تأكيد الحفظ",(dia,which)->{
                for(Store.Transaction t:parsed)store.addMoney(t);
                toast("انحفظت "+parsed.size()+" عملية على جهازك");render();
            }).setNegativeButton("إلغاء",null).show();
    }
    private String money(double amount){return String.format(Locale.US,"%,.2f",amount).replaceAll("\\.00$","");}
    private String currencyLabel(String c){return c.equals("USD")?"دولار ($)":c.equals("EUR")?"يورو (€)":"ليرة سورية (ل.س)";}
    private void exportBackup(){
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE,"yawmi-backup-"+LocalDate.now()+".json");
        startActivityForResult(intent,CREATE_BACKUP);
    }
    private void importBackup(){
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");
        startActivityForResult(intent,OPEN_BACKUP);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        if(request==CREATE_BACKUP){
            try(OutputStream stream=getContentResolver().openOutputStream(uri)){
                if(stream==null)throw new Exception("لا يمكن فتح الملف");
                stream.write(store.exportAll(prefs).toString(2).getBytes(StandardCharsets.UTF_8));
                toast("تم حفظ النسخة الاحتياطية بنجاح");
            }catch(Exception e){toast("فشل التصدير: "+e.getMessage());}
        }
        if(request==OPEN_BACKUP){
            new AlertDialog.Builder(this).setTitle("استعادة نسخة احتياطية")
                .setMessage("هالعملية رح تستبدل كل مهامك ومصاريفك الحالية ببيانات النسخة المختارة. تأكد إنك عملت تصدير لبياناتك الحالية أولاً.")
                .setPositiveButton("استعادة",(dialog,which)->{
                    try(InputStream stream=getContentResolver().openInputStream(uri)){
                        if(stream==null)throw new Exception("لا يمكن قراءة الملف");
                        ByteArrayOutputStream memory=new ByteArrayOutputStream();
                        byte[] buffer=new byte[8192];int read;
                        while((read=stream.read(buffer))!=-1){
                            memory.write(buffer,0,read);
                            if(memory.size()>15_000_000)throw new Exception("حجم الملف كبير جداً");
                        }
                        byte[] bytes=memory.toByteArray();
                        if(bytes.length>15_000_000)throw new Exception("حجم الملف كبير جداً");
                        store.importAll(new JSONObject(new String(bytes,StandardCharsets.UTF_8)),prefs);
                        PrayerScheduler.schedule(this);render();toast("تمت استعادة البيانات بنجاح");
                    }catch(Exception ex){toast("تعذرت الاستعادة: "+ex.getMessage());}
                }).setNegativeButton("إلغاء",null).show();
        }
    }
}
